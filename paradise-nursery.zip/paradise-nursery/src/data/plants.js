// Catalog data for Paradise Nursery. Each plant carries everything the
// ProductList and cart need: identity, price, category, and a description
// of how PlantArt should illustrate it.

export const categories = [
  {
    id: 'air-purifying',
    name: 'Air-Purifying Plants',
    blurb: 'Quiet workers that filter the room while they grow.',
    plants: [
      {
        id: 'snake-plant',
        name: 'Snake Plant',
        price: 24,
        description: 'Upright, architectural, and famously hard to kill.',
        art: { variant: 'blade', leaf: '#3C6B48', dark: '#21402C' },
      },
      {
        id: 'peace-lily',
        name: 'Peace Lily',
        price: 28,
        description: 'Glossy leaves and pale blooms; tells you when it\u2019s thirsty.',
        art: { variant: 'leafy', leaf: '#4C7A56', dark: '#2C5138' },
      },
      {
        id: 'areca-palm',
        name: 'Areca Palm',
        price: 36,
        description: 'Feathery fronds that bring a courtyard indoors.',
        art: { variant: 'palm', leaf: '#5C8A63', dark: '#2C5138' },
      },
    ],
  },
  {
    id: 'succulents-cacti',
    name: 'Succulents & Cacti',
    blurb: 'Low-water, high-character plants for sunny sills.',
    plants: [
      {
        id: 'echeveria',
        name: 'Echeveria',
        price: 16,
        description: 'A tidy rosette in dusty blue-green.',
        art: { variant: 'rosette', leaf: '#7FA485', dark: '#4C7A56' },
      },
      {
        id: 'barrel-cactus',
        name: 'Barrel Cactus',
        price: 19,
        description: 'Round, ribbed, and slow to change its mind.',
        art: { variant: 'barrel', leaf: '#5C8A63', dark: '#2C5138' },
      },
      {
        id: 'jade-plant',
        name: 'Jade Plant',
        price: 22,
        description: 'Coin-shaped leaves on woody little branches.',
        art: { variant: 'jade', leaf: '#5C8A63', dark: '#2C5138' },
      },
    ],
  },
  {
    id: 'flowering',
    name: 'Flowering Plants',
    blurb: 'A little color, without much fuss.',
    plants: [
      {
        id: 'african-violet',
        name: 'African Violet',
        price: 15,
        description: 'Velvety leaves, small purple blooms, all winter long.',
        art: { variant: 'flower', leaf: '#4C7A56', dark: '#2C5138', petal: '#8C5FB0', shape: 'round' },
      },
      {
        id: 'anthurium',
        name: 'Anthurium',
        price: 27,
        description: 'Waxy heart-shaped leaves under a bright red bloom.',
        art: { variant: 'flower', leaf: '#3C6B48', dark: '#21402C', petal: '#B8394A', shape: 'heart' },
      },
      {
        id: 'begonia',
        name: 'Begonia',
        price: 18,
        description: 'Patterned leaves and clusters of soft pink flowers.',
        art: { variant: 'flower', leaf: '#5C8A63', dark: '#3C6B48', petal: '#D97AA0', shape: 'oval' },
      },
    ],
  },
];

export const allPlants = categories.flatMap((c) => c.plants.map((p) => ({ ...p, category: c.name })));
